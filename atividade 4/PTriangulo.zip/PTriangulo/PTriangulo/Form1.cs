﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Forms1 : Form
    {
        public Forms1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btinLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double ladoA;
            double ladoB;
            double ladoC;

            if (!double.TryParse(txtLadoA.Text, out ladoA))
                MessageBox.Show("Lado A inválido");
            else if (!double.TryParse(txtLadoB.Text, out ladoB))
                MessageBox.Show("LadoA B Inválido");
            else if (!double.TryParse(txtLadoC.Text, out ladoC))
                MessageBox.Show("LadoA C Inválido");
            else
            {
                if (ladoA < (ladoB + ladoC) && ladoA > Math.Abs(ladoB - ladoC) &&
                   ladoB < (ladoA + ladoC) && ladoB > Math.Abs(ladoA - ladoC) &&
                   ladoC < (ladoA + ladoB) && ladoC > Math.Abs(ladoA - ladoB))
                  {
                    if ((ladoA==ladoB) && (ladoB==ladoC))
                            MessageBox.Show("O triângulo é um equilátero");
                    else if ((ladoA!=ladoB) && (ladoB != ladoC) && (ladoC != ladoA))
                            MessageBox.Show("O triângulo é um escaleno");
                    else
                        MessageBox.Show("É um isósceles");
                  }
            else
                    MessageBox.Show("lados não formam um triângulo");
            }  
        }
    }
}
