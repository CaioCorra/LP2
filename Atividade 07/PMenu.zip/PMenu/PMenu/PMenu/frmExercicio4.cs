﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void BtnQntCarac_Click(object sender, EventArgs e)
        {
            int count = 0;
            string texto = richTextBox1.Text;
            for (int i = 0; i < texto.Length; i++) 
            {
                if (char.IsNumber(texto[i]))
                {
                    count++;
                }  
            }
            MessageBox.Show(count.ToString());
        }

        private void BtnEspacoBranco_Click(object sender, EventArgs e)
        {
            int contagem = 0;
            string texto = richTextBox1.Text;
            int comprimento = texto.Length;
            int posicao;

            while (contagem < comprimento)
            {
                if (char.IsWhiteSpace(texto[contagem]))
                {
                    posicao = contagem + 1;
                    MessageBox.Show("O primeiro espaço em branco na palavra " + texto + " fica na posição " +posicao);
                    break;
                }
                contagem++;
            }
        }

        private void btnQtdAbc_Click(object sender, EventArgs e)
        {
            string text = richTextBox1.Text;
            int count = 0;

            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    count++;
                }
            }

            MessageBox.Show("O componente de texto contém " + count + " caracteres alfabéticos.");
        }
    }
}
