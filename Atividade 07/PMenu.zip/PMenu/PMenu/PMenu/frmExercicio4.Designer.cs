﻿namespace PMenu
{
    partial class FrmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQtdAbc = new System.Windows.Forms.Button();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.btnQntCarac = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnQtdAbc
            // 
            this.btnQtdAbc.Location = new System.Drawing.Point(465, 136);
            this.btnQtdAbc.Margin = new System.Windows.Forms.Padding(11);
            this.btnQtdAbc.Name = "btnQtdAbc";
            this.btnQtdAbc.Size = new System.Drawing.Size(203, 77);
            this.btnQtdAbc.TabIndex = 20;
            this.btnQtdAbc.Text = "Mostra quantos caracteres alfabeticos existem";
            this.btnQtdAbc.UseVisualStyleBackColor = true;
            this.btnQtdAbc.Click += new System.EventHandler(this.btnQtdAbc_Click);
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.Location = new System.Drawing.Point(240, 136);
            this.btnEspacoBranco.Margin = new System.Windows.Forms.Padding(11);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(203, 77);
            this.btnEspacoBranco.TabIndex = 19;
            this.btnEspacoBranco.Text = "Localiza e mostra a posicao do primeiro espaco em branco";
            this.btnEspacoBranco.UseVisualStyleBackColor = true;
            this.btnEspacoBranco.Click += new System.EventHandler(this.BtnEspacoBranco_Click);
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(20, 37);
            this.lblPalavra1.Margin = new System.Windows.Forms.Padding(11, 0, 11, 0);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(81, 24);
            this.lblPalavra1.TabIndex = 17;
            this.lblPalavra1.Text = "Palavra1";
            // 
            // btnQntCarac
            // 
            this.btnQntCarac.Location = new System.Drawing.Point(17, 136);
            this.btnQntCarac.Margin = new System.Windows.Forms.Padding(11);
            this.btnQntCarac.Name = "btnQntCarac";
            this.btnQntCarac.Size = new System.Drawing.Size(203, 77);
            this.btnQntCarac.TabIndex = 16;
            this.btnQntCarac.Text = "Quantos caracteres numéricos existem";
            this.btnQntCarac.UseVisualStyleBackColor = true;
            this.btnQntCarac.Click += new System.EventHandler(this.BtnQntCarac_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(159, 26);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(242, 35);
            this.richTextBox1.TabIndex = 21;
            this.richTextBox1.Text = "";
            // 
            // FrmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1467, 749);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.btnQtdAbc);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.lblPalavra1);
            this.Controls.Add(this.btnQntCarac);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "FrmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnQtdAbc;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Button btnQntCarac;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}