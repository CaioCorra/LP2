﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pCalculadora
{
    public partial class Form1 : Form
    {
        double num1, num2, resultado;

        private void BtnAdi_Click(object sender, EventArgs e)
        {
            if ((Double.TryParse(txtNum1.Text, out num1)) &&
            (Double.TryParse(txtNum2.Text, out num2)))
            {
                resultado = num1 + num2;
                txtResultado.Text = resultado.ToString();
            }
             else
                MessageBox.Show("caracter inválido");
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            if ((Double.TryParse(txtNum1.Text, out num1)) &&
            (Double.TryParse(txtNum2.Text, out num2)))
            {
                resultado = num1 - num2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("caracter inválido");
        }

        private void BtnMul_Click(object sender, EventArgs e)
        {
            if ((Double.TryParse(txtNum1.Text, out num1)) &&
            (Double.TryParse(txtNum2.Text, out num2)))
            {
                resultado = num1 * num2;
                txtResultado.Text = resultado.ToString();
            }
            else
                MessageBox.Show("caracter inválido");
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if ((Double.TryParse(txtNum1.Text, out num1)) &&
                (Double.TryParse(txtNum2.Text, out num2)))
            {
                if(num2 != 0)
                {
                    resultado = num1 / num2;
                    txtResultado.Text = resultado.ToString();
                }
                else
                {
                    MessageBox.Show("O Número dois não pode ser igual a 0");
                }
                
            }
            else
                MessageBox.Show("caracter inválido");
            

        }

        private void BtnLimp_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
        
        }
    }
}
